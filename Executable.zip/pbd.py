from __future__ import division
from __future__ import print_function

import math

import pickle
import pandas

import numpy as np

import torch
from torch.nn.parameter import Parameter
from torch.nn.modules.module import Module
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torch.optim.lr_scheduler import StepLR

import scipy.sparse as sp
from scipy.sparse import identity
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA


class GraphConvolution(Module):

    def __init__(self, in_features, out_features, bias=True):
        super(GraphConvolution, self).__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.weight = Parameter(torch.FloatTensor(in_features, out_features))
        if bias:
            self.bias = Parameter(torch.FloatTensor(out_features))
        else:
            self.register_parameter('bias', None)
        self.reset_parameters()

    def reset_parameters(self):
        stdv = 1. / math.sqrt(self.weight.size(1))
        self.weight.data.uniform_(-stdv, stdv)
        if self.bias is not None:
            self.bias.data.uniform_(-stdv, stdv)

    def forward(self, input, adj):
        support = torch.mm(input, self.weight)
        output = torch.spmm(adj, support)
        if self.bias is not None:
            return output + self.bias
        else:
            return output

    def __repr__(self):
        return self.__class__.__name__ + ' (' \
               + str(self.in_features) + ' -> ' \
               + str(self.out_features) + ')'


class GCN(nn.Module):
    def __init__(self, nfeat, nhid1, nhid2, nhid3, nclass, dropout):
        super(GCN, self).__init__()
        self.gc1 = GraphConvolution(nfeat, nhid1)
        self.gc2 = GraphConvolution(nhid1, nhid2)        
        self.dropout = dropout

        self.fc1 = nn.Sequential(nn.Linear(nhid2, nhid3))
        self.fc2 = nn.Sequential(nn.Linear(nhid3, nclass))

    def forward(self, x, adj):
        x = self.gc1(x, adj)
        x = F.relu(x)
        x = F.dropout(x, self.dropout, training=self.training)
        x = self.gc2(x, adj)
        x = F.relu(x)
        x = F.dropout(x, self.dropout, training=self.training)
        x = self.fc1(x)
        x = F.dropout(x, self.dropout, training=self.training)        
        x = self.fc2(x)
        return x


def encode_onehot(labels):
    classes = set(labels)
    classes_dict = {'Disease':[0,1],'Control':[1,0]}
    labels_onehot = np.array(list(map(classes_dict.get, labels)),
                             dtype=np.int32)
    return labels_onehot, classes_dict


def load_data(path="./", dataset="hplg"):
    print('Loading {} dataset...'.format(dataset))

    print('Loading features...')
    idx_features_labels = np.genfromtxt("{}{}.features".format(path, dataset),
                                        dtype=np.dtype(str))
    print('Converting to csr_matrix')
    
    protein = idx_features_labels[:, 0]
    fp = open('nodes.pkl','wb')
    pickle.dump(protein,fp)
    fp.close()
    label = idx_features_labels[:, -1]
    fp = open('label.pkl','wb')
    pickle.dump(label,fp)
    fp.close()

    features = sp.csr_matrix(idx_features_labels[:, 1:-1], dtype=np.float32)
    print('Encoding onehot...')
    labels, classes_dict = encode_onehot(idx_features_labels[:, -1])
    
    idx = np.array(idx_features_labels[:, 0], dtype=np.dtype(str))

    idx_map = {j: i for i, j in enumerate(idx)}
   
    print('End feature file... Reading network...')
    
    # load adj matrix from pickle file
    fp_nw = open('network_wcc.pkl','rb')
    adj = pickle.load(fp_nw)
    fp_nw.close()

    # build symmetric adjacency matrix
    adj = adj + adj.T.multiply(adj.T > adj) - adj.multiply(adj.T > adj)

    prediction = [1,2,3,4,5,6,7,8,9]

    features = feat_normalize(features)
    adj = normalize(adj + sp.eye(adj.shape[0]))

    features = torch.FloatTensor(np.array(features.todense()))
    
    labels = torch.LongTensor(np.where(labels)[1])
    adj = sparse_mx_to_torch_sparse_tensor(adj)

    return adj, features, labels, classes_dict, prediction


def normalize(mx):
    """Row-normalize sparse matrix"""
    rowsum = np.array(mx.sum(1))
    r_inv = np.power(rowsum, -0.5).flatten()
    r_inv[np.isinf(r_inv)] = 0.
    r_mat_inv = sp.diags(r_inv)
    mx = r_mat_inv.dot(mx)
    mx = mx.dot(r_mat_inv)
    return mx

def feat_normalize(features):
    features = pandas.DataFrame.sparse.from_spmatrix(features)
    features = pandas.DataFrame(features.loc[:,:].values)

    scaler = StandardScaler()
    features = features.loc[:,:].values
    norm_feat = pandas.DataFrame(scaler.fit_transform(features))

    pca = PCA()
    norm_feat = pandas.DataFrame(pca.fit_transform(norm_feat))

    return sp.csr_matrix(norm_feat)


def sparse_mx_to_torch_sparse_tensor(sparse_mx):
    """Convert a scipy sparse matrix to a torch sparse tensor."""
    sparse_mx = sparse_mx.tocoo().astype(np.float32)
    indices = torch.from_numpy(
        np.vstack((sparse_mx.row, sparse_mx.col)).astype(np.int64))
    values = torch.from_numpy(sparse_mx.data)
    shape = torch.Size(sparse_mx.shape)
    return torch.sparse.FloatTensor(indices, values, shape)


np.random.seed(42)
torch.manual_seed(42)

# Load data
adj, features, labels, classes_dict, prediction = load_data()

# Prediction
the_model = GCN(nfeat=features.shape[1],
            nhid1=512,
            nhid2=256,
            nhid3=256,
            nclass=labels.max().item() + 1,
            dropout=0.5)
the_model.load_state_dict(torch.load('pindel.pt'))

output = the_model(features, adj)

fp = open('nodes.pkl','rb')
protein = pickle.load(fp)
fp.close()
pred = output.max(1)[1].type_as(labels)
count = 0
ls = []
for i in prediction:
    if pred[i] == 1:
        print(protein[i], '--> Disease')
    else:
        print(protein[i], '--> Control')
